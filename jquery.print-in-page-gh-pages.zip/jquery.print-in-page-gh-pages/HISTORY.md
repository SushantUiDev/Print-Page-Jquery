# History

* v3.3.1 May 10, 2013
	* Created a new `demo` folder to store a simple index
* v3.3.0 May 1, 2013
	* Added Travis continous integration
	* Added Grunt automated tasks
	* Followed jQuery core style guide
* v3.2.0 January 17, 2013
	* Added wiki about the new jQuery Plugins Registry
	* Added package manifest for jQuery Plugins Registry

> **TODO:** Check commit history and add the rest.
